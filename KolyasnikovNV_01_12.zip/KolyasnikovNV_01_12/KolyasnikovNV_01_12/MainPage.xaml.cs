﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

using Xamarin.Essentials;

namespace KolyasnikovNV_01_12
{
    public partial class MainPage :ContentPage
    {
        public MainPage ()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            loginText.Text = Preferences.Get("login", "");
            passwordText.Text = Preferences.Get("password", "");
        }

        private async void Perehod (object sender, EventArgs e)
        {
            if (loginText.Text != "ects" && passwordText.Text != "ects2023")
            {
                await DisplayAlert("Ошибка!", "Неверно введен логин или пароль", "Повторить");
            } 
            else
            {
                Preferences.Set("login", $"{loginText.Text}");
                Preferences.Set("password", $"{passwordText.Text}");
                await Navigation.PushAsync(new Page1());
            }
        }
    }
}
