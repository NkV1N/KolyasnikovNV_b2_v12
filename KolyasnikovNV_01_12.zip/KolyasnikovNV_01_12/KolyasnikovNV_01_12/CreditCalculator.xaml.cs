﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace KolyasnikovNV_01_12
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Page1 :ContentPage
    {
        public Page1 ()
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
        }

        private async void perehod (object sender, EventArgs e)
        {
            if (int.Parse(passwordText.Text) <= 12)
            {
                double a = slider1.Value / int.Parse(passwordText.Text) + slider1.Value * 5.9;
                await Navigation.PushAsync(new ResultPage(slider1.Value.ToString(), passwordText.Text, a.ToString()));
            }
            else if (int.Parse(passwordText.Text) <= 24)
            {
                double a = slider1.Value / int.Parse(passwordText.Text) + slider1.Value * 5.1;
                await Navigation.PushAsync(new ResultPage(slider1.Value.ToString(), passwordText.Text, a.ToString()));
            } else if (int.Parse(passwordText.Text) > 24)
            {
                double a = slider1.Value / int.Parse(passwordText.Text) + slider1.Value * 4.2;
                await Navigation.PushAsync(new ResultPage(slider1.Value.ToString(), passwordText.Text, a.ToString()));
            } else
            {
                await DisplayAlert("Ошибка", "Неверно введен срок", "Ок");
            }
        }

        private async void perehodNazad (object sender, EventArgs e)
        {
            await Navigation.PopAsync();
        }
    }
}