﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace KolyasnikovNV_01_12
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ResultPage :ContentPage
    {
        public ResultPage (string Credit, string Srok, string Result)
        {
            InitializeComponent();
            NavigationPage.SetHasNavigationBar(this, false);
            credit.Text = Credit + " - Сумма кредита";
            srok.Text = Srok + " - Срок";
            resultvalue.Text = Result + " - Результат";
        }

        private async void Nazad (object sender, EventArgs e)
        {
            await Navigation.PushAsync(new MainPage());
        }
    }
}